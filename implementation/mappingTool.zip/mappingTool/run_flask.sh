export FLASK_APP=flask_app.py
export FLASK_DEBUG=1
flask run