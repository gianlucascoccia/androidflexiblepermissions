setwd("/Users/gianlucascoccia/Desktop/afp-mapping/results")

peaklens = read.csv2("peaklens-results.csv", header = FALSE, stringsAsFactors = FALSE)
fivesec = read.csv2("5sec-results.csv", header = FALSE, stringsAsFactors = FALSE)
ums = read.csv2("ums-results.csv", header = FALSE, stringsAsFactors = FALSE)
electrosmart = read.csv2("electrosmart-results.csv", header = FALSE, stringsAsFactors = FALSE)
knownmovies = read.csv2("knownmovies-results.csv", header = FALSE, stringsAsFactors = FALSE)
foodel = read.csv2("foodel-results.csv", header = FALSE, stringsAsFactors = FALSE)
yopapp = read.csv2("yopapp-results.csv", header = FALSE, stringsAsFactors = FALSE)
ambiens = read.csv2("ambiens-results.csv", header = FALSE, stringsAsFactors = FALSE)
mymensa = read.csv2("mymensa-results.csv", header = FALSE, stringsAsFactors = FALSE)

dataframes = list(peaklens, fivesec, ums, electrosmart, knownmovies, foodel, yopapp, ambiens, mymensa)

# for(df in dataframes){
#   df['feature_time'] = c(0,(data.frame(diff(as.matrix(df['V3']))/ 1000 ) / 60)$V3)
#   df['cumulative_time'] = ((df['V3'] - df[1,'V3']) / 1000 ) / 60
#   print(df)
# }

# for(df in dataframes){
#   for (features in df['V1']){
#     for(f in unique(features)){
#       rows = df[df['V1'] == f]
#       print(length(rows))
#       str(rows)
#     }  
#   }
# }

features = print(unique(foodel['V1']))
for (f in features['V1']){
  nrows = nrow(foodel[foodel['V1'] == f])
  print(nrows)
}

